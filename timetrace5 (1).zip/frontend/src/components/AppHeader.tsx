import React, { useState, useRef, useEffect } from 'react';
import {
  Clock,
  LayoutDashboard,
  CalendarRange,
  Database,
  Sparkles,
  Laptop,
  LogOut,
  Shield,
  ChevronDown,
} from 'lucide-react';
import { DeviceState, PrimaryNavTab, UserProfile } from '@shared/types/chronotrace';

interface AppHeaderProps {
  activeTab: PrimaryNavTab;
  onSelectTab: (tab: PrimaryNavTab) => void;
  user: UserProfile | null;
  device: DeviceState | null;
  liveFileActive?: boolean;
  onOpenDeviceModal: () => void;
  onOpenPrivacyModal: () => void;
  onLogout: () => void;
  onNavigateToDeviceScreen?: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  activeTab,
  onSelectTab,
  user,
  device,
  liveFileActive = false,
  onOpenDeviceModal,
  onOpenPrivacyModal,
  onLogout,
  onNavigateToDeviceScreen,
}) => {
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: { id: PrimaryNavTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'timeline', label: 'Timeline', icon: CalendarRange },
    { id: 'raw', label: 'Activity', icon: Database },
    { id: 'assistant', label: 'AI Assistant', icon: Sparkles },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Left: Brand Identity */}
          <div className="flex items-center gap-6">
            <div
              onClick={() => onSelectTab('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer select-none"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
                <Clock className="w-4 h-4 stroke-[2.2]" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-slate-900 tracking-tight text-base leading-none">
                  ChronoTrace
                </span>
                <span className="text-[10px] text-slate-500 font-medium tracking-wide mt-0.5">
                  Activity Reconstruction
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center space-x-1 pl-4 border-l border-slate-200">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                      isActive
                        ? 'text-blue-600 bg-blue-50/70 font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    <Icon
                      className={`w-4 h-4 ${
                        isActive ? 'text-blue-600' : 'text-slate-400'
                      }`}
                    />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Right Controls: Device Status and User Profile */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            {/* Compact Device Connection Indicator Button */}
            <button
              onClick={onOpenDeviceModal}
              title="Click to view device connection details or connect laptop"
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer border border-slate-200 shadow-2xs"
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  device?.status === 'CONNECTED' || device?.status === 'CONNECTED_AWAITING_ACTIVITY'
                    ? 'bg-emerald-500 animate-pulse'
                    : device?.status === 'RECONNECTING'
                    ? 'bg-amber-500 animate-pulse'
                    : device?.status === 'DISCONNECTED' || device?.status === 'ERROR'
                    ? 'bg-amber-500'
                    : 'bg-slate-400'
                }`}
              />
              <Laptop className="w-3.5 h-3.5 text-slate-500 hidden sm:inline" />
              <span className="hidden sm:inline">
                {device?.status === 'CONNECTED'
                  ? 'Connected · Live Stream'
                  : device?.status === 'CONNECTED_AWAITING_ACTIVITY'
                  ? 'Connected · Awaiting Activity'
                  : device?.status === 'RECONNECTING'
                  ? 'Reconnecting…'
                  : device?.paused
                  ? 'Collection Paused'
                  : device?.status === 'DISCONNECTED' || device?.status === 'ERROR'
                  ? 'Disconnected · Reconnect'
                  : 'Connect Device'}
              </span>
            </button>

            {/* User Profile Menu */}
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-full hover:bg-slate-100 transition-colors cursor-pointer border border-transparent focus:border-slate-300"
              >
                {user?.picture ? (
                  <img
                    src={user.picture}
                    alt={user.name || 'User'}
                    className="w-7 h-7 rounded-full object-cover border border-slate-200"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-semibold flex items-center justify-center">
                    {user?.name ? user.name.charAt(0) : 'U'}
                  </div>
                )}
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {profileOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-xl shadow-lg py-2 z-50 text-xs">
                  {/* Account Info */}
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <div className="font-semibold text-slate-900 text-sm">{user?.name || 'User'}</div>
                    <div className="text-slate-500 text-[11px] truncate">{user?.email || ''}</div>
                  </div>

                  {/* Menu options */}
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setProfileOpen(false);
                        onOpenDeviceModal();
                      }}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2 text-slate-700 hover:bg-slate-50 cursor-pointer text-left"
                    >
                      <Laptop className="w-3.5 h-3.5 text-blue-600" />
                      <span>Device Status &amp; Connection</span>
                    </button>

                    <button
                      onClick={() => {
                        setProfileOpen(false);
                        onOpenPrivacyModal();
                      }}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2 text-slate-700 hover:bg-slate-50 cursor-pointer text-left"
                    >
                      <Shield className="w-3.5 h-3.5 text-slate-400" />
                      <span>Privacy &amp; Data Policy</span>
                    </button>
                  </div>

                  {/* Sign Out */}
                  <div className="pt-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setProfileOpen(false);
                        onLogout();
                      }}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2 text-rose-600 hover:bg-rose-50 cursor-pointer text-left font-medium"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-500" />
                      <span>Sign out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-100 overflow-x-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`flex flex-col items-center gap-1 px-2.5 py-1 text-xs rounded-lg cursor-pointer whitespace-nowrap ${
                  isActive ? 'text-blue-600 font-semibold' : 'text-slate-500'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};

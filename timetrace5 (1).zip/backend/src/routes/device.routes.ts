import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions, newDeviceToken } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// -------------------------------------------------------------
// DEVICE STATUS & CONTROL ENDPOINTS
// -------------------------------------------------------------

router.get('/api/device/status', (req, res) => {
  const user = res.locals.user as UserRecord;
  const rec = getUserDeviceRecord(user.id);
  const telemetry = getUserTelemetry(user.id);
  res.json(toDeviceStatus(rec, telemetry.length));
});

router.post('/api/device/regenerate-token', (req, res) => {
  const user = res.locals.user as UserRecord;
  const users = getUsers();
  const u = users.find((x) => x.id === user.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  const newToken = newDeviceToken();
  u.deviceToken = newToken;
  saveUsers(users);

  // Reset device record so any stale connection from the revoked token is cleared
  const rec = getUserDeviceRecord(user.id);
  rec.lastHeartbeatAt = null;
  rec.connectedSince = null;
  saveUserDeviceRecord(user.id, rec);

  const telemetry = getUserTelemetry(user.id);
  res.json({
    success: true,
    deviceToken: newToken,
    device: toDeviceStatus(rec, telemetry.length),
    message: 'New device token generated. Previous token has been revoked.',
  });
});

router.get(['/api/agent/status', '/api/agent/state'], (req, res) => {
  const user = res.locals.user as UserRecord;
  const rec = getUserDeviceRecord(user.id);
  const telemetry = getUserTelemetry(user.id);
  const sessions = getUserSessions(user.id);
  const status = toDeviceStatus(rec, telemetry.length);
  const lastEvent = telemetry[telemetry.length - 1];

  res.json({
    ...status,
    device: status.deviceName,
    eventsCapturedToday: telemetry.length,
    sessionChunksRecorded: sessions.length,
    currentWindowTitle: status.connected ? (rec.currentWindowTitle || 'Waiting for activity') : null,
    currentForegroundApp: status.connected ? (rec.currentForegroundApp || 'Idle') : null,
    activeAnchor: sessions[sessions.length - 1]?.anchor_app || 'No anchor app',
    lastSync: status.lastHeartbeatAt || null,
    isPaused: status.paused,
    status: status.status,
    connectionState: status.connected ? 'online' : status.status === 'RECONNECTING' ? 'reconnecting' : status.paused ? 'paused' : 'offline',
  });
});

router.post('/api/device/toggle', (req, res) => {
  const user = res.locals.user as UserRecord;
  const rec = getUserDeviceRecord(user.id);
  rec.paused = !Boolean(req.body?.connected);
  if (rec.paused) rec.connectedSince = null;
  saveUserDeviceRecord(user.id, rec);
  const telemetry = getUserTelemetry(user.id);
  res.json({ success: true, device: toDeviceStatus(rec, telemetry.length) });
});

router.post('/api/device/connect', (req, res) => {
  const user = res.locals.user as UserRecord;
  const rec = getUserDeviceRecord(user.id);
  rec.paused = false;
  saveUserDeviceRecord(user.id, rec);
  const telemetry = getUserTelemetry(user.id);
  const status = toDeviceStatus(rec, telemetry.length);
  res.json({
    success: status.connected,
    connected: status.connected,
    device: status,
    message: status.connected
      ? 'Agent verified: heartbeats are actively arriving from your Windows device.'
      : 'Waiting for heartbeat from Windows agent. Please run the PowerShell command and keep the window open.',
  });
});

router.post('/api/device/disconnect', (req, res) => {
  const user = res.locals.user as UserRecord;
  const rec = getUserDeviceRecord(user.id);
  rec.paused = true;
  rec.connectedSince = null;
  saveUserDeviceRecord(user.id, rec);
  const telemetry = getUserTelemetry(user.id);
  res.json({ success: true, device: toDeviceStatus(rec, telemetry.length) });
});

router.post('/api/agent/control', (req, res) => {
  const { action } = req.body;
  const user = res.locals.user as UserRecord;
  const rec = getUserDeviceRecord(user.id);
  if (action === 'pause') {
    rec.paused = true;
    rec.connectedSince = null;
    saveUserDeviceRecord(user.id, rec);
  } else if (action === 'resume') {
    rec.paused = false;
    saveUserDeviceRecord(user.id, rec);
  }
  const telemetry = getUserTelemetry(user.id);
  const status = toDeviceStatus(rec, telemetry.length);
  res.json({
    success: true,
    action,
    message:
      action === 'test'
        ? status.connected
          ? 'Agent connected · Latency: 12ms'
          : 'No heartbeat from Windows agent yet'
        : `Agent ${action}d successfully`,
    device: status,
  });
});


export default router;

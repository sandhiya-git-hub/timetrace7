import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// backend/ folder (this file lives in backend/src/config)
export const BACKEND_ROOT = path.resolve(__dirname, '..', '..');
// Repository root (one level above backend/)
export const PROJECT_ROOT = path.resolve(BACKEND_ROOT, '..');

// Load backend/.env (the documented location) and the repo-root .env as a fallback.
// dotenv never overrides a variable that is already set, so the first file wins.
// Without this, `npm run dev` from the root silently ignored backend/.env.
dotenv.config({ path: path.join(BACKEND_ROOT, '.env') });
dotenv.config({ path: path.join(PROJECT_ROOT, '.env') });

export const IS_PRODUCTION =
  process.env.NODE_ENV === 'production' || process.argv.includes('--production');

function getPort(): number {
  const portArgIndex = process.argv.indexOf('--port');
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    return Number(process.argv[portArgIndex + 1]);
  }
  if (process.env.APP_PORT) {
    return Number(process.env.APP_PORT);
  }
  // If PORT is 8080, nginx is listening on 8080 and proxying to 3000
  if (process.env.PORT && process.env.PORT !== '8080') {
    return Number(process.env.PORT);
  }
  return 3000;
}
export const PORT = getPort();

// Data lives in backend/data by default (persistent). Override with CHRONOTRACE_DATA_DIR.
export const DATA_DIR = process.env.CHRONOTRACE_DATA_DIR || path.join(BACKEND_ROOT, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Python agent that /api/download-agent serves
export const AGENT_FILE = path.resolve(PROJECT_ROOT, 'agent', 'chronotrace_agent.py');

// Built frontend (served by Express in production)
export const FRONTEND_DIST = path.resolve(PROJECT_ROOT, 'frontend', 'dist');

// Google GenAI SDK, strictly server-side
export const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
});

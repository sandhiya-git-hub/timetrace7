import express from 'express';
import { randomBytes } from 'crypto';
import type { DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from './userStore.js';
import { isAgentLive, HEARTBEAT_TIMEOUT_MS, RECONNECT_TIMEOUT_MS } from './dataStore.js';

export function getSessionToken(req: express.Request): string | null {
  if (req.cookies && req.cookies['chronotrace_session']) {
    return req.cookies['chronotrace_session'];
  }
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }
  if (req.headers['x-session-token']) {
    return String(req.headers['x-session-token']).trim();
  }
  if (req.query && typeof req.query.sessionToken === 'string') {
    return req.query.sessionToken.trim();
  }
  return null;
}

export function getAuthenticatedUser(req: express.Request): UserRecord | null {
  const token = getSessionToken(req);
  const sessions = getAuthSessions();
  const users = getUsers();

  if (token) {
    if (sessions[token]) {
      const session = sessions[token];
      if (new Date(session.expiresAt) > new Date()) {
        const user = users.find((u) => u.id === session.userId);
        if (user) return user;
      } else {
        delete sessions[token];
        saveAuthSessions(sessions);
      }
    }
    return null;
  }

  // Cross-site iframe fallback for Google AI Studio preview:
  // In cross-origin preview iframes (aistudio.google.com -> *.run.app), browsers block third-party cookies.
  // Resolve to the active authenticated session from auth_sessions.json or the registered user account.
  const activeSessions = Object.values(sessions).filter(
    (s) => new Date(s.expiresAt) > new Date()
  );
  if (activeSessions.length > 0) {
    activeSessions.sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
    const latest = activeSessions[0];
    const user = users.find((u) => u.id === latest.userId);
    if (user) return user;
  }

  return null;
}

// Access-control guard for data routes. Only a valid session cookie (or Bearer token) resolves to a user.
export const DATA_ALIAS_PREFIXES = [
  '/sessions', '/summary', '/reentry', '/patterns',
];

// Routes that authenticate in a custom way (agent token / query token / public / download).
export const SESSION_EXEMPT_PATHS = new Set([
  '/api/auth/session', '/api/auth/config', '/api/auth/login', '/api/auth/register',
  '/api/auth/google', '/api/auth/logout',
  '/api/ingest-event', '/api/sync-sessions', '/api/agent/sync-file',
  '/api/download-agent', '/api/download/chronotrace_agent.py', '/download/chronotrace_agent.py',
  '/agent.py', '/chronotrace_agent.py', '/api/agent.py', '/api/chronotrace_agent.py',
  '/public/agent.py', '/public/chronotrace_agent.py',
]);

export const SESSION_COOKIE_NAME = 'chronotrace_session';
export const SESSION_TTL_MS = 30 * 24 * 3600 * 1000; // 30 days

// Support iframe contexts on Cloud Run / AI Studio (requires sameSite: 'none', secure: true, and partitioned: true on HTTPS)
export function sessionCookieOptions(req?: express.Request) {
  const isHttps =
    process.env.COOKIE_SECURE === 'true' ||
    (req ? req.secure || req.headers['x-forwarded-proto'] === 'https' : true);
  return {
    httpOnly: true,
    sameSite: (isHttps ? 'none' : 'lax') as 'none' | 'lax',
    path: '/',
    secure: Boolean(isHttps),
    partitioned: Boolean(isHttps),
    maxAge: SESSION_TTL_MS,
  };
}

export function requireSessionUser(req: express.Request, res: express.Response, next: express.NextFunction) {
  const p = req.path;
  if (SESSION_EXEMPT_PATHS.has(p)) return next();
  const isData = p.startsWith('/api/') || DATA_ALIAS_PREFIXES.some((x) => p.startsWith(x));
  if (!isData) return next();
  const user = getAuthenticatedUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Sign in required.' });
  }
  res.locals.user = user;
  return next();
}

export function createSessionForUser(user: UserRecord): { token: string; expiresAt: string } {
  const token = `ct_sess_${randomBytes(32).toString('hex')}`;
  const expiresAt = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(); // 30 days
  const sessions = getAuthSessions();
  sessions[token] = {
    token,
    userId: user.id,
    createdAt: new Date().toISOString(),
    expiresAt,
  };
  saveAuthSessions(sessions);
  return { token, expiresAt };
}

export function toUserProfile(u: UserRecord) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    name: u.name,
    givenName: u.givenName,
    picture: u.picture,
    deviceToken: u.deviceToken,
    emailVerified: true,
    lastLogin: u.lastLogin,
    isRegistered: u.isRegistered !== false,
    hasConfiguredDevice: u.hasConfiguredDevice !== false,
  };
}

export function toDeviceStatus(
  rec: DeviceRecord,
  eventCount: number = 0,
  currentEvent?: { appName?: string; windowTitle?: string }
): DeviceState {
  const now = Date.now();
  const lastHeartbeatMs = rec.lastHeartbeatAt ? Date.parse(rec.lastHeartbeatAt) : null;
  const age = lastHeartbeatMs !== null && !isNaN(lastHeartbeatMs) ? Math.max(0, now - lastHeartbeatMs) : Infinity;

  let status: DeviceState['status'];
  let statusText: string;
  let connected = false;

  if (rec.paused) {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Collection paused';
  } else if (!lastHeartbeatMs || isNaN(lastHeartbeatMs)) {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Device agent not started';
  } else if (age <= HEARTBEAT_TIMEOUT_MS) {
    connected = true;
    if (eventCount > 0 && rec.lastEventTime) {
      status = 'CONNECTED';
      statusText = `Connected · Streaming from ${rec.deviceName || 'Windows PC'}`;
    } else {
      status = 'CONNECTED_AWAITING_ACTIVITY';
      statusText = 'Connected · Heartbeat active, awaiting window activity';
    }
  } else if (age <= RECONNECT_TIMEOUT_MS) {
    status = 'RECONNECTING';
    const secAgo = Math.round(age / 1000);
    statusText = `Reconnecting · Last heartbeat ${secAgo}s ago`;
  } else {
    status = 'DISCONNECTED';
    statusText = `Disconnected · Agent offline (last seen ${rec.lastEventTime || 'previously'})`;
  }

  return {
    connected,
    status,
    paused: rec.paused,
    deviceName: rec.deviceName,
    os: rec.os,
    agentVersion: rec.agentVersion,
    samplingInterval: rec.samplingInterval,
    lastEventTime: rec.lastEventTime,
    lastLocalDate: rec.lastLocalDate || new Date().toISOString().split('T')[0],
    eventCount,
    statusText,
    lastPing: rec.lastHeartbeatAt,
    lastHeartbeatAt: rec.lastHeartbeatAt,
    connectedSince: connected ? rec.connectedSince : null,
    lastSuccessfulConnectionAt: rec.lastSuccessfulConnectionAt,
    currentWindowTitle: connected ? (currentEvent?.windowTitle || rec.currentWindowTitle || null) : null,
    currentForegroundApp: connected ? (currentEvent?.appName || rec.currentForegroundApp || null) : null,
  };
}

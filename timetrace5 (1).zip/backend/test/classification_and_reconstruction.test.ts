import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../src/app.js';
import { DATA_DIR } from '../src/config/env.js';
import {
  getUserTelemetry,
  getUserSessions,
  saveUserTelemetry,
  saveUserSessions,
  saveUserDeviceRecord,
  saveUserSummary,
  saveUserPreferences,
  getUserPreferences,
  saveUserEventIndex,
  getUserEventIndex,
} from '../src/services/dataStore.js';
import { getUsers, saveUsers, newDeviceToken } from '../src/services/userStore.js';
import { createSessionForUser } from '../src/services/authHelpers.js';
import { classifyActivity } from '../../shared/classification/classifier.js';

describe('ChronoTrace Classification, Reconstruction and Analytics Accuracy Suite', () => {
  let server: http.Server;
  let baseUrl: string;

  const testUserId = 'usr_accuracy_test_999';
  const testDeviceToken = newDeviceToken();
  let testSessionToken: string;

  before(async () => {
    // Register test user
    const users = getUsers().filter((u) => u.id !== testUserId);
    users.push({
      id: testUserId,
      username: 'accuracy_tester',
      email: 'tester@chronotrace.local',
      passwordHash: 'dummy',
      name: 'Accuracy Tester',
      givenName: 'Accuracy',
      deviceToken: testDeviceToken,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    });
    saveUsers(users);

    const session = createSessionForUser({
      id: testUserId,
      username: 'accuracy_tester',
      email: 'tester@chronotrace.local',
      deviceToken: testDeviceToken,
      name: 'Accuracy Tester',
      passwordHash: 'dummy',
      createdAt: new Date().toISOString(),
    });
    testSessionToken = session.token;

    // Clean test user directory
    const userDir = path.join(DATA_DIR, 'users', testUserId);
    if (fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
    saveUserTelemetry(testUserId, []);
    saveUserSessions(testUserId, []);
    saveUserPreferences(testUserId, []);
    saveUserEventIndex(testUserId, new Set());
    saveUserDeviceRecord(testUserId, {
      paused: false,
      deviceName: 'Windows Workstation',
      os: 'Windows 11 64-bit',
      agentVersion: '1.3.0',
      samplingInterval: '500ms',
      lastHeartbeatAt: new Date().toISOString(),
      connectedSince: new Date().toISOString(),
      lastSuccessfulConnectionAt: new Date().toISOString(),
      lastEventTime: null,
      lastLocalDate: null,
    });

    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address() as any;
        baseUrl = `http://127.0.0.1:${addr.port}`;
        resolve();
      });
    });
  });

  after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    const users = getUsers().filter((u) => u.id !== testUserId);
    saveUsers(users);
    const userDir = path.join(DATA_DIR, 'users', testUserId);
    if (fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
  });

  async function apiCall(method: string, endpoint: string, headers: Record<string, string> = {}, body?: any) {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {}
    return { status: res.status, body: json };
  }

  function getAuthHeaders() {
    return {
      Authorization: `Bearer ${testSessionToken}`,
      Cookie: `chronotrace_session=${testSessionToken}`,
    };
  }
  const agentHeaders = {
    'X-Device-Token': testDeviceToken,
  };

  // 1. Intelligent Classification Unit Tests
  it('1. Intelligent Classification: accurately distinguishes YouTube educational vs entertainment vs ambiguous', () => {
    // Educational YouTube content
    const eduRes = classifyActivity(
      'Google Chrome',
      'React 19 Architecture and Compiler Deep Dive Tutorial - YouTube'
    );
    assert.equal(eduRes.category, 'Learning & Research');
    assert.equal(eduRes.intent, 'LEARNING');
    assert.ok(eduRes.confidence >= 0.85);
    assert.match(eduRes.reason, /tutorial|academic/i);

    // Entertainment / Song / Movie YouTube content (including Tamil film song from user screenshot)
    const entRes = classifyActivity(
      'Google Chrome',
      'Magale | Baththa | Sai Abhyankar | Vijay Sethupathi | Official Video - YouTube'
    );
    assert.equal(entRes.category, 'Entertainment');
    assert.equal(entRes.intent, 'DISTRACTION');
    assert.ok(entRes.confidence >= 0.85);

    // Trailer / Movie clip
    const trailerRes = classifyActivity('Google Chrome', 'Inception Official Movie Trailer - YouTube');
    assert.equal(trailerRes.category, 'Entertainment');

    // Ambiguous YouTube content (home page or no clear signal)
    const ambigRes = classifyActivity('Google Chrome', 'YouTube - Google Chrome');
    assert.equal(ambigRes.category, 'Unclassified');
    assert.equal(ambigRes.intent, 'UNKNOWN');
    assert.ok(ambigRes.confidence <= 0.5);
    assert.match(ambigRes.reason, /insufficient/i);
  });

  it('2. Collector Process Exclusion: excludes ChronoTrace PowerShell collector from deep work', () => {
    const collectorRes = classifyActivity('PowerShell', 'PowerShell - python chronotrace_agent.py');
    assert.equal(collectorRes.category, 'Utility / Admin');
    assert.equal(collectorRes.isCollectorProcess, true);
    assert.match(collectorRes.reason, /excluded from productivity/i);
  });

  it('3. Code editor classification: distinguishes active development from empty/untitled editor', () => {
    const activeCode = classifyActivity('VS Code', 'server.ts - ChronoTrace - Visual Studio Code');
    assert.equal(activeCode.category, 'Deep Work');
    assert.equal(activeCode.intent, 'DEEP_WORK');
    assert.ok(activeCode.confidence >= 0.85);

    const emptyEditor = classifyActivity('VS Code', 'Visual Studio Code');
    assert.equal(emptyEditor.category, 'Unclassified');
    assert.ok(emptyEditor.confidence < 0.6);
  });

  // 4. Repeated Window Events & Dwell Calculation
  it('4. Repeated window events accumulate dwell without creating duplicate sessions', async () => {
    // Emit initial window event: 10 seconds in VS Code
    const ev1 = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_repeat_1',
      appName: 'VS Code',
      windowTitle: 'analytics.routes.ts - ChronoTrace',
      deltaSeconds: 10,
      localTime: '10:00:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ev1.status, 200);

    // Emit second event in same active window: 15 seconds in VS Code
    const ev2 = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_repeat_2',
      appName: 'VS Code',
      windowTitle: 'analytics.routes.ts - ChronoTrace',
      deltaSeconds: 15,
      localTime: '10:00:10 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ev2.status, 200);

    const sessions = getUserSessions(testUserId);
    assert.equal(sessions.length, 1);
    assert.equal(sessions[0].duration_s, 25);
    assert.equal(sessions[0].anchor_app, 'VS Code');
    assert.equal(sessions[0].main_events?.length, 1);
    assert.equal(sessions[0].main_events?.[0].dwell_s, 25);

    // Verify raw events are preserved intact
    const telemetry = getUserTelemetry(testUserId);
    assert.equal(telemetry.length, 2);
    assert.equal(telemetry[0].dwell_ms, 10000);
    assert.equal(telemetry[1].dwell_ms, 15000);
  });

  // 5. Collector Process Ingestion & Metrics Exclusion
  it('5. PowerShell ChronoTrace collector events are excluded from deep work and distraction totals', async () => {
    const collectorEv = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_collector_1',
      appName: 'PowerShell',
      windowTitle: 'PowerShell - python chronotrace_agent.py',
      deltaSeconds: 30,
      localTime: '10:00:25 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(collectorEv.status, 200);

    const telem = getUserTelemetry(testUserId);
    const lastTelem = telem[telem.length - 1];
    assert.equal(lastTelem.is_collector_process, true);
    assert.equal(lastTelem.category, 'Utility / Admin');

    // Query summary: total tracked duration should include collector (30s) + VS Code (25s) = 55s,
    // but total_deep_work_s must ONLY be 25s (collector excluded)!
    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', getAuthHeaders());
    assert.equal(summaryRes.status, 200);
    assert.equal(summaryRes.body.total_telemetry_s, 55);
    assert.equal(summaryRes.body.total_deep_work_s, 25);
    assert.equal(summaryRes.body.total_distraction_s, 0);
  });

  // 6. Rapid Application Switching
  it('6. Rapid application switching transitions sessions without losing raw events', async () => {
    const apps = [
      { app: 'Google Chrome', title: 'React 19 Documentation - Google Chrome', s: 5 },
      { app: 'Slack', title: 'Slack | team-engineering | Acme Corp', s: 8 },
      { app: 'VS Code', title: 'server.ts - ChronoTrace', s: 20 },
    ];

    for (let i = 0; i < apps.length; i++) {
      const res = await apiCall('POST', '/api/ingest-event', agentHeaders, {
        id: `evt_rapid_${i}`,
        appName: apps[i].app,
        windowTitle: apps[i].title,
        deltaSeconds: apps[i].s,
        localTime: `10:01:0${i} AM`,
        localDate: '2026-10-30',
        sourceType: 'os-hook',
      });
      assert.equal(res.status, 200);
    }

    const telemetry = getUserTelemetry(testUserId);
    assert.ok(telemetry.length >= 6);

    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', getAuthHeaders());
    assert.ok(summaryRes.body.context_switches >= 3);
  });

  // 7. Duplicate Prevention (Idempotency)
  it('7. Submitting duplicate event twice is rejected and does not double durations', async () => {
    const dupPayload = {
      id: 'evt_exact_unique_123',
      appName: 'VS Code',
      windowTitle: 'dup_test.ts - ChronoTrace',
      deltaSeconds: 50,
      localTime: '10:05:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    };

    // First ingestion
    const firstRes = await apiCall('POST', '/api/ingest-event', agentHeaders, dupPayload);
    assert.equal(firstRes.status, 200);
    assert.equal(firstRes.body.ingested, 1);
    assert.equal(firstRes.body.duplicates, 0);

    // Second ingestion with identical ID and signature
    const secondRes = await apiCall('POST', '/api/ingest-event', agentHeaders, dupPayload);
    assert.equal(secondRes.status, 200);
    assert.equal(secondRes.body.ingested, 0);
    assert.equal(secondRes.body.duplicates, 1);
  });

  // 8. User-Controlled Corrections & Preference Persistence
  it('8. User can correct session classification, persisting preference for future matching activities', async () => {
    // 1. Ingest an ambiguous YouTube event that defaults to Unclassified
    const ytAmbigRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_ambig_yt_1',
      appName: 'Google Chrome',
      windowTitle: 'Custom Tech Stream - YouTube',
      deltaSeconds: 40,
      localTime: '10:10:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ytAmbigRes.status, 200);

    const sessions = getUserSessions(testUserId);
    const lastSession = sessions[sessions.length - 1];
    assert.equal(lastSession.dominant_category, 'Unclassified');

    // 2. User manually corrects this session to 'Learning & Research' / 'LEARNING'
    const correctRes = await apiCall(
      'POST',
      `/api/sessions/${lastSession.chunk_id}/correct`,
      getAuthHeaders(),
      { intent: 'LEARNING', category: 'Learning & Research' }
    );
    assert.equal(correctRes.status, 200);
    assert.equal(correctRes.body.success, true);
    assert.equal(correctRes.body.chunk.user_corrected, true);
    assert.equal(correctRes.body.chunk.dominant_category, 'Learning & Research');

    // Verify user preference was persisted
    const prefs = getUserPreferences(testUserId);
    assert.ok(prefs.length > 0);
    assert.equal(prefs[prefs.length - 1].category, 'Learning & Research');

    // 3. Ingest a future event matching the same window title
    const nextEventRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_ambig_yt_future_match',
      appName: 'Google Chrome',
      windowTitle: 'Custom Tech Stream - YouTube',
      deltaSeconds: 30,
      localTime: '10:12:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(nextEventRes.status, 200);

    // Verify that the new event was automatically classified as Learning & Research from user preference rule
    const telem = getUserTelemetry(testUserId);
    const matchedEv = telem.find((e) => e.id === 'evt_ambig_yt_future_match');
    assert.ok(matchedEv);
    assert.equal(matchedEv?.category, 'Learning & Research');
    assert.equal(matchedEv?.confidence, 1.0);
    assert.match(matchedEv?.classification_reason ?? '', /user classification preference/i);
  });

  // 9. Insufficient Data and Productivity Guardrails
  it('9. Zero and insufficient-data states are handled honestly without false productivity labeling', async () => {
    // Create an isolated user with 0 telemetry
    const zeroUserId = 'usr_zero_test_000';
    const users = getUsers();
    users.push({
      id: zeroUserId,
      username: 'zero_user',
      email: 'zero@chronotrace.local',
      passwordHash: 'dummy',
      name: 'Zero User',
      deviceToken: 'ct_dev_zero_user_tok',
      createdAt: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    });
    saveUsers(users);

    const zeroSession = createSessionForUser({
      id: zeroUserId,
      username: 'zero_user',
      email: 'zero@chronotrace.local',
      deviceToken: 'ct_dev_zero_user_tok',
      name: 'Zero User',
      passwordHash: 'dummy',
      createdAt: new Date().toISOString(),
    });

    const res = await apiCall('GET', '/api/summary', { Authorization: `Bearer ${zeroSession.token}` });
    assert.equal(res.status, 200);
    assert.equal(res.body.total_telemetry_s, 0);
    assert.equal(res.body.total_deep_work_s, 0);
    assert.equal(res.body.work_state, 'AWAITING_ACTIVITY');

    // Clean up
    saveUsers(getUsers().filter((u) => u.id !== zeroUserId));
  });

  // 10. Date Range Analytics & Raw Telemetry Date Filtering Regression
  it('10. Analytics date filtering correctly scopes summaries and raw telemetry without cross-date bleeding', async () => {
    // Ingest events across two distinct dates: 2026-10-29 and 2026-10-30
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_day1_vscode',
      appName: 'VS Code',
      windowTitle: 'day1.ts - ChronoTrace',
      deltaSeconds: 60,
      localTime: '09:00:00 AM',
      localDate: '2026-10-29',
      sourceType: 'os-hook',
    });

    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_day2_vscode',
      appName: 'VS Code',
      windowTitle: 'day2.ts - ChronoTrace',
      deltaSeconds: 40,
      localTime: '09:00:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });

    // Query for only 2026-10-29
    const day1Summary = await apiCall(
      'GET',
      '/api/summary?startDate=2026-10-29&endDate=2026-10-29',
      getAuthHeaders()
    );
    assert.equal(day1Summary.status, 200);
    assert.equal(day1Summary.body.total_telemetry_s, 60);

    // Query raw telemetry with date filter for 2026-10-29
    const day1Raw = await apiCall(
      'GET',
      '/api/telemetry/raw?date=2026-10-29',
      getAuthHeaders()
    );
    assert.equal(day1Raw.status, 200);
    assert.equal(day1Raw.body.events.length, 1);
    assert.equal(day1Raw.body.events[0].id, 'evt_day1_vscode');

    // Query 7-day range preset
    const weekSummary = await apiCall('GET', '/api/summary?range=week', getAuthHeaders());
    assert.equal(weekSummary.status, 200);
    assert.ok(weekSummary.body.total_telemetry_s >= 100);
  });

  // 11. Sync-file (chronotrace_live.json) Ingestion Parity & Collector Exclusion
  it('11. Sync-file route applies intelligent classification and excludes PowerShell collector', async () => {
    const syncRes = await apiCall('POST', '/api/agent/sync-file', agentHeaders, {
      sessions: [
        {
          id: 'sync_sess_collector',
          appName: 'PowerShell',
          windowTitle: 'PowerShell - python chronotrace_agent.py',
          durationSeconds: 45,
          startTime: '11:00:00 AM',
          endTime: '11:00:45 AM',
        },
        {
          id: 'sync_sess_yt_edu',
          appName: 'Google Chrome',
          windowTitle: 'TypeScript 5 Deep Dive Course - YouTube',
          durationSeconds: 120,
          startTime: '11:01:00 AM',
          endTime: '11:03:00 AM',
        },
      ],
      deviceName: 'Windows Laptop',
      os: 'Windows 11',
    });
    assert.equal(syncRes.status, 200);

    const telem = getUserTelemetry(testUserId);
    const collectorEv = telem.find((e) => e.id?.includes('sync_sess_collector'));
    assert.ok(collectorEv);
    assert.equal(collectorEv?.is_collector_process, true);
    assert.equal(collectorEv?.category, 'Utility / Admin');

    const eduEv = telem.find((e) => e.id?.includes('sync_sess_yt_edu'));
    assert.ok(eduEv);
    assert.equal(eduEv?.category, 'Learning & Research');
    assert.ok((eduEv?.confidence ?? 0) >= 0.85);
  });

  // 12. Immutability of Raw Telemetry upon User Correction
  it('12. User classification corrections do not mutate or overwrite original raw telemetry', async () => {
    // Find raw telemetry before correction
    const telemBefore = getUserTelemetry(testUserId);
    const targetRaw = telemBefore.find((e) => e.id === 'evt_ambig_yt_1');
    assert.ok(targetRaw);
    assert.equal(targetRaw?.category, 'Unclassified');

    // Verify raw telemetry retained original category even though session was corrected to Learning
    const telemAfter = getUserTelemetry(testUserId);
    const targetRawAfter = telemAfter.find((e) => e.id === 'evt_ambig_yt_1');
    assert.equal(targetRawAfter?.category, 'Unclassified');
  });
});

import type { IntentLabel } from '../types/chronotrace.js';

export interface ActivityContext {
  url?: string;
  domain?: string;
  scrollCount?: number;
  clickCount?: number;
  keyCount?: number;
  activeDwellMs?: number;
  idleDwellMs?: number;
  isIdle?: boolean;
  isVisible?: boolean;
}

export interface ClassificationResult {
  category: 'Deep Work' | 'Learning & Research' | 'Communication' | 'Entertainment' | 'Utility / Admin' | 'Unclassified';
  intent: IntentLabel;
  confidence: number;
  reason: string;
  task: string;
  isCollectorProcess?: boolean;
  engagementState?: 'active' | 'passive' | 'idle';
}

export interface UserPreferenceRule {
  id: string;
  appPattern?: string;
  titlePattern?: string;
  domainPattern?: string;
  urlPattern?: string;
  category: 'Deep Work' | 'Learning & Research' | 'Communication' | 'Entertainment' | 'Utility / Admin' | 'Unclassified';
  intent: IntentLabel;
  createdAt: string;
}

// Regex patterns with word boundaries to prevent substring false-positives
const EDUCATIONAL_PATTERNS = [
  /\b(tutorial|tutorials|course|courses|lecture|lectures|lesson|lessons)\b/i,
  /\b(algorithm|algorithms|data\s+structure|data\s+structures|leetcode|neetcode)\b/i,
  /\b(dijkstra|graph\s+theory|dynamic\s+programming|binary\s+tree|sorting)\b/i,
  /\b(cs50|freecodecamp|fireship|3blue1brown|mit\s+opencourseware|coursera|udemy|edx)\b/i,
  /\b(crash\s+course|masterclass|bootcamp|workshop|webinar|deep\s+dive)\b/i,
  /\b(calculus|linear\s+algebra|differential\s+equations|discrete\s+math)\b/i,
  /\b(physics|chemistry|biology|neuroscience|biochemistry|quantum)\b/i,
  /\b(system\s+design|microservices|distributed\s+systems|cloud\s+architecture)\b/i,
  /\b(python|javascript|typescript|react|nextjs|nodejs|golang|rustlang|docker|kubernetes)\s+(tutorial|crash|guide|intro|explained|basics|architecture)\b/i,
  /\b(how\s+to\s+(build|code|program|implement|solve|deploy|design))\b/i,
  /\b(explained\s+simply|understanding\s+how|in-depth\s+analysis|research\s+paper)\b/i,
];

const ENTERTAINMENT_PATTERNS = [
  /\b(official\s+video|official\s+music\s+video|lyric\s+video|lyrics|audio\s+track)\b/i,
  /\b(song|songs|remix|acoustic|karaoke|live\s+concert|soundtrack|ost|playlist)\b/i,
  /\b(trailer|teaser|official\s+trailer|teaser\s+trailer|sneak\s+peek)\b/i,
  /\b(movie|film|cinema|box\s+office|full\s+movie|movie\s+scene|film\s+clip)\b/i,
  /\b(episode\s+\d+|season\s+\d+|s\d+e\d+|series\s+finale|sitcom|anime|kdrama)\b/i,
  /\b(gameplay|playthrough|walkthrough\s+part|stream\s+highlights|twitch\s+stream)\b/i,
  /\b(valorant|minecraft|fortnite|gta\s+v|roblox|pubg|apex\s+legends|fifa|elden\s+ring)\b/i,
  /\b(prank|funny|comedy|standup|meme|memes|roast|reaction|parody|vlog)\b/i,
  /\b(netflix|disney\+|hulu|prime\s+video|hotstar|hbo|crunchyroll)\b/i,
  /\b(asmr|mukbang|shorts\s+feed|tiktok|reels|challenge)\b/i,
  /\b(highlights|cricket|ipl|fifa\s+world\s+cup|nba|football\s+highlights)\b/i,
];

const CODE_FILE_PATTERN = /\.(ts|tsx|js|jsx|py|go|rs|cpp|c|h|java|html|css|json|sql|md|yml|yaml|env|toml)\b/i;

// Domain & URL path categorizations
const LEARNING_DOMAINS = [
  'coursera.org', 'udemy.com', 'edx.org', 'khanacademy.org', 'freecodecamp.org',
  'leetcode.com', 'neetcode.io', 'hackerrank.com', 'codecademy.com', 'duolingo.com',
  'developer.mozilla.org', 'w3schools.com', 'stackoverflow.com', 'stackexchange.com',
  'docs.python.org', 'react.dev', 'nodejs.org', 'typescriptlang.org', 'rust-lang.org',
  'golang.org', 'pkg.go.dev', 'docs.rs', 'pypi.org', 'npmjs.com', 'arxiv.org',
  'scholar.google.com', 'wikipedia.org', 'nature.com', 'science.org', 'researchgate.net',
  'mit.edu', 'stanford.edu', 'harvard.edu', 'geeksforgeeks.org', 'devdocs.io'
];

const DEEP_WORK_DOMAINS = [
  'github.com', 'gitlab.com', 'bitbucket.org', 'figma.com', 'canva.com',
  'linear.app', 'atlassian.net', 'jira.com', 'trello.com', 'asana.com', 'monday.com',
  'notion.so', 'overleaf.com', 'docs.google.com', 'sheets.google.com', 'slides.google.com',
  'console.cloud.google.com', 'portal.azure.com', 'aws.amazon.com', 'vercel.com',
  'supabase.com', 'cloudflare.com', 'codepen.io', 'codesandbox.io', 'replit.com',
  'stackblitz.com', 'databox.com', 'miro.com', 'lucidchart.com'
];

const COMMUNICATION_DOMAINS = [
  'slack.com', 'teams.microsoft.com', 'discord.com', 'mail.google.com',
  'outlook.live.com', 'outlook.office.com', 'web.whatsapp.com', 'web.telegram.org',
  'meet.google.com', 'zoom.us', 'gmail.com', 'basecamp.com'
];

const ENTERTAINMENT_DOMAINS = [
  'netflix.com', 'twitch.tv', 'disneyplus.com', 'hulu.com', 'primevideo.com',
  'crunchyroll.com', 'tiktok.com', 'instagram.com', 'facebook.com', 'twitter.com',
  'x.com', 'spotify.com', 'soundcloud.com', 'steampowered.com', 'epicgames.com',
  'roblox.com', 'vimeo.com', 'hotstar.com', 'hbo.com', 'max.com'
];

const SEARCH_DOMAINS = [
  'google.com', 'bing.com', 'duckduckgo.com', 'kagi.com', 'perplexity.ai', 'search.brave.com'
];

export function extractDomainFromUrl(rawUrl?: string): string {
  if (!rawUrl) return '';
  try {
    const parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
    return parsed.hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
}

export function classifyActivity(
  appName: string,
  windowTitle: string,
  userPreferences: UserPreferenceRule[] = [],
  context?: ActivityContext
): ClassificationResult {
  const cleanApp = (appName || 'Active Window').trim();
  const cleanTitle = (windowTitle || cleanApp).trim();
  const appLower = cleanApp.toLowerCase();
  const titleLower = cleanTitle.toLowerCase();

  // Extract URL domain if available
  const domain = context?.domain || extractDomainFromUrl(context?.url) || '';
  const domainLower = domain.toLowerCase();
  const rawUrl = (context?.url || '').toLowerCase();

  // Calculate engagement state
  const totalInteractions = (context?.clickCount || 0) + (context?.scrollCount || 0) + (context?.keyCount || 0);
  const activeMs = context?.activeDwellMs || 0;
  const idleMs = context?.idleDwellMs || 0;
  const isIdle = Boolean(
    context?.isIdle ||
    (idleMs > 30000 && idleMs >= activeMs * 2 && totalInteractions === 0)
  );
  const engagementState: 'active' | 'passive' | 'idle' = isIdle
    ? 'idle'
    : totalInteractions > 2 || activeMs > 10000
    ? 'active'
    : 'passive';

  // 1. Check user-defined preference corrections first (highest priority)
  for (const pref of userPreferences) {
    let appMatch = true;
    let titleMatch = true;
    let domainMatch = true;
    let urlMatch = true;

    if (pref.appPattern) {
      appMatch = appLower.includes(pref.appPattern.toLowerCase());
    }
    if (pref.titlePattern) {
      titleMatch = titleLower.includes(pref.titlePattern.toLowerCase());
    }
    if (pref.domainPattern && domainLower) {
      domainMatch = domainLower.includes(pref.domainPattern.toLowerCase());
    }
    if (pref.urlPattern && rawUrl) {
      urlMatch = rawUrl.includes(pref.urlPattern.toLowerCase());
    }

    if (appMatch && titleMatch && domainMatch && urlMatch) {
      return {
        category: pref.category,
        intent: pref.intent,
        confidence: 1.0,
        reason: 'User classification preference rule',
        task: `${cleanApp}: ${cleanTitle}`,
        engagementState,
      };
    }
  }

  // 2. ChronoTrace Agent / Collector Process Exclusion
  const isTerminalApp =
    appLower.includes('powershell') ||
    appLower.includes('terminal') ||
    appLower.includes('cmd') ||
    appLower === 'command prompt';

  const isCollectorTitle =
    titleLower.includes('chronotrace_agent.py') ||
    titleLower.includes('chronotrace_agent') ||
    titleLower.includes('agent.py') ||
    (titleLower.includes('chronotrace') && isTerminalApp);

  if (isCollectorTitle) {
    return {
      category: 'Utility / Admin',
      intent: 'ADMIN',
      confidence: 1.0,
      reason: 'ChronoTrace collector background process (excluded from productivity metrics)',
      task: 'ChronoTrace Collector Agent',
      isCollectorProcess: true,
      engagementState: 'passive',
    };
  }

  // 3. Browser-specific URL & Domain Telemetry (if browser context is present)
  if (domainLower) {
    // Check Search Engines
    if (SEARCH_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`))) {
      return {
        category: 'Learning & Research',
        intent: 'LEARNING',
        confidence: 0.88,
        reason: `Web search & research query via ${domain}`,
        task: `Search: ${cleanTitle.replace(/- Google Search|- Bing|- DuckDuckGo$/i, '').trim() || cleanTitle}`,
        engagementState,
      };
    }

    // Check Learning & Research Domains
    if (LEARNING_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`))) {
      if (isIdle) {
        return {
          category: 'Unclassified',
          intent: 'UNKNOWN',
          confidence: 0.5,
          reason: `Documentation (${domain}) open but idle without interaction (excluded from deep focus)`,
          task: `Idle: ${cleanTitle}`,
          engagementState: 'idle',
        };
      }
      return {
        category: 'Learning & Research',
        intent: 'LEARNING',
        confidence: 0.94,
        reason: `Educational platform or technical documentation verified on ${domain}`,
        task: `${cleanTitle} (${domain})`,
        engagementState,
      };
    }

    // Check Deep Work Domains
    if (DEEP_WORK_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`))) {
      if (isIdle) {
        return {
          category: 'Unclassified',
          intent: 'UNKNOWN',
          confidence: 0.5,
          reason: `Work tool (${domain}) open but idle without user interaction`,
          task: `Idle: ${cleanTitle}`,
          engagementState: 'idle',
        };
      }
      return {
        category: 'Deep Work',
        intent: 'DEEP_WORK',
        confidence: 0.94,
        reason: `Productivity, design, or engineering workspace verified on ${domain}`,
        task: `${cleanTitle} (${domain})`,
        engagementState,
      };
    }

    // Check Communication Domains
    if (COMMUNICATION_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`))) {
      return {
        category: 'Communication',
        intent: 'COMMUNICATION',
        confidence: 0.92,
        reason: `Communication service active on ${domain}`,
        task: `Communication: ${cleanTitle}`,
        engagementState,
      };
    }

    // Check Entertainment Domains
    if (ENTERTAINMENT_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`))) {
      return {
        category: 'Entertainment',
        intent: 'DISTRACTION',
        confidence: 0.94,
        reason: `Entertainment or social media stream detected on ${domain}`,
        task: `Entertainment: ${cleanTitle}`,
        engagementState,
      };
    }

    // Reddit special handling: technical subreddits vs general feeds
    if (domainLower.includes('reddit.com')) {
      const isTechSubreddit = /\/r\/(programming|typescript|javascript|reactjs|python|golang|rust|webdev|cscareerquestions|datascience|algorithms)\b/i.test(rawUrl || cleanTitle);
      if (isTechSubreddit) {
        return {
          category: 'Learning & Research',
          intent: 'LEARNING',
          confidence: 0.85,
          reason: 'Technical programming subreddit research',
          task: `Reddit (Tech): ${cleanTitle}`,
          engagementState,
        };
      }
      return {
        category: 'Entertainment',
        intent: 'DISTRACTION',
        confidence: 0.85,
        reason: 'General social browsing on Reddit',
        task: `Reddit: ${cleanTitle}`,
        engagementState,
      };
    }
  }

  // 4. YouTube & Video Streaming Context (Title & URL)
  const isYouTube =
    domainLower.includes('youtube.com') ||
    domainLower.includes('youtu.be') ||
    titleLower.includes('youtube') ||
    appLower.includes('youtube');

  if (isYouTube) {
    const isEducational = EDUCATIONAL_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl));
    const isEntertainment = ENTERTAINMENT_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl));

    // If clearly educational and not marked as music/trailer/entertainment
    if (isEducational && !isEntertainment) {
      if (isIdle) {
        return {
          category: 'Unclassified',
          intent: 'UNKNOWN',
          confidence: 0.5,
          reason: 'YouTube educational video left paused or idle without active interaction',
          task: `YouTube (Idle): ${cleanTitle.replace(/- YouTube$/i, '').trim()}`,
          engagementState: 'idle',
        };
      }
      return {
        category: 'Learning & Research',
        intent: 'LEARNING',
        confidence: 0.9,
        reason: 'Technical tutorial or academic lecture identified from video title',
        task: `YouTube (Learning): ${cleanTitle.replace(/- YouTube$/i, '').trim()}`,
        engagementState,
      };
    }

    // If clearly entertainment, music, movie or comedy
    if (isEntertainment) {
      return {
        category: 'Entertainment',
        intent: 'DISTRACTION',
        confidence: 0.92,
        reason: 'Music, trailer, or leisure media identified from video title',
        task: `YouTube (Entertainment): ${cleanTitle.replace(/- YouTube$/i, '').trim()}`,
        engagementState,
      };
    }

    // Generic YouTube home, search, or ambiguous title without clear markers
    return {
      category: 'Unclassified',
      intent: 'UNKNOWN',
      confidence: 0.4,
      reason: 'Insufficient title evidence to confirm educational or entertainment intent',
      task: `YouTube: ${cleanTitle.replace(/- YouTube$/i, '').trim() || 'Browsing'}`,
      engagementState,
    };
  }

  // 5. Code Editors & IDEs (VS Code, JetBrains, Sublime, etc.)
  const isIde =
    appLower.includes('code') ||
    appLower.includes('studio') ||
    appLower.includes('intellij') ||
    appLower.includes('pycharm') ||
    appLower.includes('webstorm') ||
    appLower.includes('xcode') ||
    appLower.includes('sublime') ||
    appLower.includes('vim') ||
    appLower.includes('neovim');

  if (isIde) {
    // Check if user is completely idle in the editor
    if (isIdle) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.5,
        reason: 'Code editor open but left idle without typing or navigation (idle dwell excluded from deep focus)',
        task: `${cleanApp}: Idle workspace`,
        engagementState: 'idle',
      };
    }

    // Check if there is an active file being edited
    const hasCodeFile = CODE_FILE_PATTERN.test(cleanTitle);
    const isGenericEditor =
      cleanTitle.toLowerCase() === 'visual studio code' ||
      cleanTitle.toLowerCase() === 'code' ||
      cleanTitle.toLowerCase() === 'untitled';

    if (hasCodeFile || cleanTitle.includes(' - ')) {
      return {
        category: 'Deep Work',
        intent: 'DEEP_WORK',
        confidence: 0.95,
        reason: 'Active code editor with open project/file buffer',
        task: `Editing ${cleanTitle.split(' - ')[0] || cleanTitle}`,
        engagementState,
      };
    }

    if (isGenericEditor) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.45,
        reason: 'Editor open without active document or workspace context',
        task: `${cleanApp}: Empty workspace`,
        engagementState,
      };
    }

    return {
      category: 'Deep Work',
      intent: 'DEEP_WORK',
      confidence: 0.85,
      reason: 'Software development environment active',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 6. Team Communication & Messaging Apps
  const isCommunication =
    appLower.includes('slack') ||
    appLower.includes('whatsapp') ||
    appLower.includes('teams') ||
    appLower.includes('discord') ||
    appLower.includes('telegram') ||
    appLower.includes('zoom') ||
    titleLower.includes('gmail') ||
    titleLower.includes('outlook') ||
    titleLower.includes('google meet');

  if (isCommunication) {
    return {
      category: 'Communication',
      intent: 'COMMUNICATION',
      confidence: 0.9,
      reason: 'Direct communication or meeting application',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 7. Technical Documentation & Cloud Consoles (when domain is not present in context)
  const isDocOrResearch =
    titleLower.includes('stackoverflow.com') ||
    titleLower.includes('stack overflow') ||
    titleLower.includes('developer.mozilla.org') ||
    titleLower.includes('github.com') ||
    titleLower.includes('gitlab.com') ||
    titleLower.includes('arxiv.org') ||
    titleLower.includes('rfc-editor.org') ||
    titleLower.includes('ai studio') ||
    titleLower.includes('console.cloud.google.com') ||
    titleLower.includes('aws management console');

  if (isDocOrResearch) {
    if (isIdle) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.5,
        reason: 'Technical documentation open but idle without interaction',
        task: `Idle: ${cleanTitle}`,
        engagementState: 'idle',
      };
    }
    return {
      category: 'Deep Work',
      intent: 'DEEP_WORK',
      confidence: 0.9,
      reason: 'Technical documentation, repository, or cloud infrastructure console',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 8. Productivity & Design Suites (Figma, Notion, Docs)
  const isProductivityTool =
    appLower.includes('figma') ||
    appLower.includes('notion') ||
    titleLower.includes('google docs') ||
    titleLower.includes('google sheets') ||
    titleLower.includes('overleaf') ||
    titleLower.includes('linear.app') ||
    titleLower.includes('jira');

  if (isProductivityTool) {
    if (isIdle) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.5,
        reason: 'Design or document editor open but idle without interaction',
        task: `Idle: ${cleanTitle}`,
        engagementState: 'idle',
      };
    }
    return {
      category: 'Deep Work',
      intent: 'DEEP_WORK',
      confidence: 0.88,
      reason: 'Active design, planning, or technical document preparation',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 9. General Entertainment & Social Media
  const isSocialOrLeisure =
    titleLower.includes('reddit.com') ||
    titleLower.includes('twitter.com') ||
    titleLower.includes('x.com') ||
    titleLower.includes('instagram.com') ||
    titleLower.includes('facebook.com') ||
    titleLower.includes('netflix.com') ||
    titleLower.includes('twitch.tv') ||
    appLower.includes('spotify') ||
    appLower.includes('steam');

  if (isSocialOrLeisure) {
    return {
      category: 'Entertainment',
      intent: 'DISTRACTION',
      confidence: 0.85,
      reason: 'Social media, gaming, or media consumption platform',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 10. OS Utilities & Administration
  const isSystemUtility =
    appLower.includes('calculator') ||
    appLower.includes('calc') ||
    appLower.includes('explorer') ||
    appLower.includes('task manager') ||
    appLower.includes('settings') ||
    appLower.includes('finder');

  if (isSystemUtility) {
    return {
      category: 'Utility / Admin',
      intent: 'ADMIN',
      confidence: 0.85,
      reason: 'Operating system utility or file management tool',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 11. Generic browser new tabs / empty windows -> Unclassified
  const isGenericTab =
    titleLower === 'new tab' ||
    titleLower === 'google' ||
    titleLower === 'chrome' ||
    titleLower === 'edge' ||
    titleLower === 'start page' ||
    titleLower.trim() === '';

  if (isGenericTab) {
    return {
      category: 'Unclassified',
      intent: 'UNKNOWN',
      confidence: 0.3,
      reason: 'Generic browser navigation without specific task content',
      task: `${cleanApp}: New Tab`,
      engagementState: 'passive',
    };
  }

  // 12. Default fallback: Unclassified instead of guessing
  return {
    category: 'Unclassified',
    intent: 'UNKNOWN',
    confidence: 0.35,
    reason: 'Insufficient contextual signals to classify activity',
    task: `${cleanApp}: ${cleanTitle}`,
    engagementState,
  };
}

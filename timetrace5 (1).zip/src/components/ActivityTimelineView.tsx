import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  Clock,
  Laptop,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  Info,
  Check,
  Edit2,
  ListFilter,
  Globe,
  Activity,
  MousePointer,
} from 'lucide-react';
import { ChunkSummary, IntentLabel } from '@shared/types/chronotrace';

interface ActivityTimelineViewProps {
  chunks: ChunkSummary[];
  onCorrectIntent?: (chunkId: string, newIntent: IntentLabel) => void;
  onOpenDeviceModal?: () => void;
}

export const ActivityTimelineView: React.FC<ActivityTimelineViewProps> = ({
  chunks,
  onCorrectIntent,
  onOpenDeviceModal,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [appFilter, setAppFilter] = useState<string>('ALL');
  const [expandedChunkId, setExpandedChunkId] = useState<string | null>(null);
  const [editingIntentChunkId, setEditingIntentChunkId] = useState<string | null>(null);

  // Group consecutive related chunks from the same anchor application to avoid repetitive micro-cards
  const groupedSessions = useMemo(() => {
    if (!chunks || chunks.length === 0) return [];

    // Filter out obsolete dummy seed chunks when real device sessions are recorded
    const hasLive = chunks.some(
      (c) => c.chunk_id?.startsWith('live_') || c.chunk_id?.startsWith('local-') || !c.chunk_id?.includes('seed')
    );
    const baseChunks = hasLive
      ? chunks.filter((c) => !c.chunk_id?.includes('seed-'))
      : chunks;

    // Consolidate consecutive chunks in the same application and category
    const result: ChunkSummary[] = [];

    for (let i = 0; i < baseChunks.length; i++) {
      const current = { ...baseChunks[i] };
      const last = result[result.length - 1];

      // If the last session has the same application and intent, and occurred within 2 minutes of current
      if (
        last &&
        last.anchor_app?.toLowerCase() === current.anchor_app?.toLowerCase() &&
        last.intent === current.intent &&
        !current.user_corrected &&
        !last.user_corrected
      ) {
        // Merge into last session
        last.duration_s += current.duration_s;
        last.end_time = current.end_time || last.end_time;
        // Merge main events
        const mergedEvents = [...(last.main_events || [])];
        (current.main_events || []).forEach((e) => {
          const existing = mergedEvents.find((m) => m.title === e.title && m.app === e.app);
          if (existing) {
            existing.dwell_s += e.dwell_s;
            existing.keys = (existing.keys || 0) + (e.keys || 0);
          } else {
            mergedEvents.push({ ...e });
          }
        });
        last.main_events = mergedEvents;
        last.summary = `Continuous work in ${last.anchor_app} (${Math.round(last.duration_s / 60)}m dwell across ${mergedEvents.length} window transitions).`;
      } else {
        result.push(current);
      }
    }

    return result;
  }, [chunks]);

  // Extract unique applications from actual sessions
  const uniqueApps = useMemo(() => {
    const apps = new Set<string>();
    groupedSessions.forEach((c) => {
      if (c.anchor_app) apps.add(c.anchor_app);
      c.main_events?.forEach((e) => {
        if (e.app) apps.add(e.app);
      });
    });
    return Array.from(apps).sort();
  }, [groupedSessions]);

  // Filtering logic
  const filteredChunks = useMemo(() => {
    return groupedSessions.filter((c) => {
      // Category filter
      if (categoryFilter !== 'ALL') {
        const cat = c.intent || c.dominant_category || '';
        if (categoryFilter === 'FOCUS' && cat !== 'DEEP_WORK') return false;
        if (categoryFilter === 'LEARNING' && cat !== 'LEARNING') return false;
        if (categoryFilter === 'DISTRACTION' && cat !== 'DISTRACTION' && cat !== 'DISTRACTION_BREAK') return false;
        if (categoryFilter === 'UTILITY' && cat !== 'ADMIN' && cat !== 'Utility') return false;
        if (categoryFilter === 'UNCLASSIFIED' && cat !== 'UNCLASSIFIED' && c.confidence && c.confidence > 0.6) return false;
      }

      // App filter
      if (appFilter !== 'ALL') {
        const matchesAnchor = c.anchor_app?.toLowerCase().includes(appFilter.toLowerCase());
        const matchesSubEvent = c.main_events?.some((e) =>
          e.app.toLowerCase().includes(appFilter.toLowerCase())
        );
        if (!matchesAnchor && !matchesSubEvent) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTask = c.primary_task?.toLowerCase().includes(q);
        const matchesSummary = c.summary?.toLowerCase().includes(q);
        const matchesApp = c.anchor_app?.toLowerCase().includes(q);
        const matchesEvents = c.main_events?.some(
          (e) => e.title?.toLowerCase().includes(q) || e.app?.toLowerCase().includes(q)
        );
        if (!matchesTask && !matchesSummary && !matchesApp && !matchesEvents) return false;
      }

      return true;
    });
  }, [groupedSessions, categoryFilter, appFilter, searchQuery]);

  // Format duration into readable text
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.round(seconds % 60);
    if (mins > 0 && secs > 0) return `${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m`;
    return `${secs}s`;
  };

  // Human category styling & labels adhering to zero-pill discipline
  const getCategoryDetails = (intent?: string) => {
    switch (intent) {
      case 'DEEP_WORK':
        return {
          label: 'Deep Focus',
          textClass: 'text-blue-700 font-semibold',
          dotClass: 'bg-blue-600',
        };
      case 'LEARNING':
        return {
          label: 'Learning & Research',
          textClass: 'text-emerald-700 font-semibold',
          dotClass: 'bg-emerald-600',
        };
      case 'DISTRACTION':
      case 'DISTRACTION_BREAK':
        return {
          label: 'Distraction',
          textClass: 'text-rose-700 font-semibold',
          dotClass: 'bg-rose-600',
        };
      case 'COMMUNICATION':
        return {
          label: 'Communication',
          textClass: 'text-purple-700 font-semibold',
          dotClass: 'bg-purple-600',
        };
      case 'ADMIN':
      case 'Utility':
        return {
          label: 'Utility / Admin',
          textClass: 'text-cyan-800 font-semibold',
          dotClass: 'bg-cyan-600',
        };
      default:
        return {
          label: 'Unclassified',
          textClass: 'text-slate-600 font-medium',
          dotClass: 'bg-slate-400',
        };
    }
  };

  // Build evidence explanation from actual available data
  const getClassificationEvidence = (chunk: ChunkSummary) => {
    if (chunk.classification_reason) {
      return chunk.classification_reason;
    }
    if (chunk.is_collector_process) {
      return 'ChronoTrace background collector process (excluded from productivity metrics).';
    }
    if (chunk.user_corrected) {
      return 'Classified by user manual confirmation (saved as user preference rule for future matching activities).';
    }

    const parts: string[] = [];
    const dwellMinutes = Math.round(chunk.duration_s / 60);

    if (dwellMinutes >= 1) {
      parts.push(`Sustained dwell of ${dwellMinutes}m in ${chunk.anchor_app || 'application'}`);
    } else {
      parts.push(`${Math.round(chunk.duration_s)}s dwell in ${chunk.anchor_app || 'application'}`);
    }

    const switchCount = chunk.main_events?.length || 1;
    if (switchCount === 1) {
      parts.push('0 context switches (single window)');
    } else {
      parts.push(`${switchCount} window switches within session`);
    }

    if (chunk.keyboard && chunk.keyboard.total_keys > 0) {
      parts.push(`active typing recorded (${chunk.keyboard.total_keys} keys)`);
    }

    if (chunk.distraction_detected) {
      parts.push('classified under entertainment trigger');
    }

    return `Classification evidence: ${parts.join(', ')}.`;
  };

  const toggleExpand = (chunkId: string) => {
    setExpandedChunkId((prev) => (prev === chunkId ? null : chunkId));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header and overview */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">
            Activity Timeline
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Chronological reconstruction of foreground activity grouped into coherent cognitive sessions
          </p>
        </div>

        <div className="text-xs text-slate-500 font-mono tabular-nums">
          Showing {filteredChunks.length} of {groupedSessions.length} sessions
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by window title, application name, or task..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 placeholder:text-slate-400"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 shrink-0">
              <Filter className="w-3.5 h-3.5" />
              <span>Category:</span>
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              <option value="FOCUS">Deep Focus</option>
              <option value="LEARNING">Learning &amp; Research</option>
              <option value="DISTRACTION">Distraction</option>
              <option value="UTILITY">Utility / Admin</option>
              <option value="UNCLASSIFIED">Unclassified</option>
            </select>
          </div>

          {/* Application Filter */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={appFilter}
              onChange={(e) => setAppFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">All Applications</option>
              {uniqueApps.map((app) => (
                <option key={app} value={app}>
                  {app}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Timeline Stream */}
      {groupedSessions.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center max-w-lg mx-auto shadow-2xs">
          <Clock className="w-8 h-8 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-900">No activity sessions recorded yet</h3>
          <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
            ChronoTrace groups continuous foreground window dwell and transitions into meaningful cognitive focus sessions. Run the Windows telemetry agent to begin reconstructing your work day.
          </p>
          {onOpenDeviceModal && (
            <button
              onClick={onOpenDeviceModal}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-2xs transition-colors cursor-pointer"
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>Connect Device</span>
            </button>
          )}
        </div>
      ) : filteredChunks.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <HelpCircle className="w-7 h-7 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-slate-900">No sessions match your filter</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Try adjusting your search terms, application selection, or category filters.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setCategoryFilter('ALL');
              setAppFilter('ALL');
            }}
            className="mt-3 text-xs font-medium text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            Clear all filters
          </button>
        </div>
      ) : (
        <div className="relative pl-6 sm:pl-8 space-y-4 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
          {filteredChunks.map((chunk, idx) => {
            const cat = getCategoryDetails(chunk.intent);
            const isExpanded = expandedChunkId === chunk.chunk_id;
            const confidence = chunk.confidence ? Math.round(chunk.confidence * 100) : null;
            const isUncertain = !confidence || confidence < 60;
            const evidence = getClassificationEvidence(chunk);
            const isEditingIntent = editingIntentChunkId === chunk.chunk_id;

            return (
              <div key={chunk.chunk_id || idx} className="relative group">
                {/* Node icon on vertical line */}
                <div
                  className={`absolute -left-6 sm:-left-8 top-5 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center shadow-2xs ${cat.dotClass}`}
                />

                {/* Main Session Card */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs hover:border-slate-300 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      {/* Quiet unboxed metadata header */}
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-mono font-semibold text-slate-900 tabular-nums">
                          {chunk.start_time} – {chunk.end_time}
                        </span>
                        <span className="text-slate-300" aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums text-slate-700 font-medium">
                          {formatDuration(chunk.duration_s)}
                        </span>
                        {(chunk.active_duration_s !== undefined && chunk.idle_duration_s !== undefined && (chunk.idle_duration_s > 0 || chunk.active_duration_s > 0)) && (
                          <>
                            <span className="text-slate-300" aria-hidden="true">·</span>
                            <span className="text-emerald-700 font-mono text-[11px]">
                              {formatDuration(chunk.active_duration_s)} active
                            </span>
                            {chunk.idle_duration_s > 0 && (
                              <span className="text-amber-700 font-mono text-[11px]">
                                · {formatDuration(chunk.idle_duration_s)} idle
                              </span>
                            )}
                          </>
                        )}
                        <span className="text-slate-300" aria-hidden="true">·</span>
                        <span className={cat.textClass}>{cat.label}</span>
                        <span className="text-slate-300" aria-hidden="true">·</span>
                        <span className="text-slate-600 font-medium flex items-center gap-1">
                          {chunk.domain ? (
                            <>
                              <Globe className="w-3 h-3 text-blue-600 shrink-0" />
                              <span>{chunk.domain}</span>
                              <span className="text-slate-400">({chunk.anchor_app})</span>
                            </>
                          ) : (
                            chunk.anchor_app
                          )}
                        </span>
                        <span className="text-slate-300" aria-hidden="true">·</span>
                        {isUncertain ? (
                          <span className="text-amber-700 font-medium">Needs review</span>
                        ) : (
                          <span className="text-slate-500 font-mono tabular-nums">{confidence}% confidence</span>
                        )}
                        {chunk.engagement_score !== undefined && (
                          <>
                            <span className="text-slate-300" aria-hidden="true">·</span>
                            <span className="text-slate-500 text-[11px] font-mono flex items-center gap-1">
                              <Activity className="w-3 h-3 text-indigo-500" />
                              {chunk.engagement_score}% engaged ({chunk.engagement_state || 'active'})
                            </span>
                          </>
                        )}
                        {((chunk.click_count || 0) > 0 || (chunk.scroll_count || 0) > 0) && (
                          <>
                            <span className="text-slate-300" aria-hidden="true">·</span>
                            <span className="text-slate-500 text-[11px] font-mono flex items-center gap-1">
                              <MousePointer className="w-3 h-3 text-slate-400" />
                              {chunk.click_count || 0}c / {chunk.scroll_count || 0}s
                            </span>
                          </>
                        )}
                        {chunk.user_corrected && (
                          <>
                            <span className="text-slate-300" aria-hidden="true">·</span>
                            <span className="text-blue-700 text-[11px] font-medium flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              User confirmed
                            </span>
                          </>
                        )}
                      </div>

                      {/* Title & Primary Task */}
                      <h3 className="text-base font-semibold text-slate-900 pt-0.5">
                        {chunk.primary_task || `${chunk.anchor_app}: Activity Session`}
                      </h3>

                      {/* Natural language summary & evidence */}
                      <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                        {chunk.summary || `Active foreground work interval in ${chunk.anchor_app}.`}
                      </p>

                      {/* Concrete evidence badge */}
                      <div className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-200/80 font-mono leading-relaxed mt-2">
                        {evidence}
                      </div>
                    </div>

                    {/* Actions: View sub-events & Correct classification */}
                    <div className="flex items-center gap-2 shrink-0 self-start">
                      {onCorrectIntent && (
                        <button
                          onClick={() => setEditingIntentChunkId(isEditingIntent ? null : chunk.chunk_id)}
                          className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 font-medium px-2.5 py-1.5 rounded-lg hover:bg-slate-50 transition-colors border border-slate-200 cursor-pointer"
                          title="Correct intent classification"
                        >
                          <Edit2 className="w-3 h-3 text-slate-400" />
                          <span>Classify</span>
                        </button>
                      )}

                      <button
                        onClick={() => toggleExpand(chunk.chunk_id)}
                        className="inline-flex items-center gap-1.5 text-xs text-slate-700 hover:text-slate-900 font-medium px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-colors border border-slate-200 cursor-pointer"
                      >
                        <span>{isExpanded ? 'Hide Sub-events' : `Sub-events (${chunk.main_events?.length || 1})`}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Intent correction selector */}
                  {isEditingIntent && (
                    <div className="mt-3 p-3.5 rounded-lg bg-blue-50/50 border border-blue-200 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-800">Change activity classification:</span>
                        <span className="text-[11px] text-blue-700">Persists as user preference for future matching activities</span>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {(['DEEP_WORK', 'LEARNING', 'COMMUNICATION', 'DISTRACTION', 'ADMIN', 'UNKNOWN'] as IntentLabel[]).map((label) => (
                          <button
                            key={label}
                            onClick={() => {
                              onCorrectIntent?.(chunk.chunk_id, label);
                              setEditingIntentChunkId(null);
                            }}
                            className={`px-2.5 py-1 rounded text-xs font-medium cursor-pointer transition-colors ${
                              chunk.intent === label
                                ? 'bg-blue-600 text-white'
                                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                            }`}
                          >
                            {getCategoryDetails(label).label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Expandable sub-events drawer with exact timestamps for auditing */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-slate-100 space-y-3">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
                        <div className="flex items-center gap-1.5">
                          <Laptop className="w-3.5 h-3.5 text-slate-500" />
                          <span>Window Transitions &amp; Dwell Auditing</span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-normal">
                          Exact timestamps &amp; dwell recorded by local agent
                        </span>
                      </div>

                      <div className="space-y-1.5">
                        {chunk.main_events && chunk.main_events.length > 0 ? (
                          chunk.main_events.map((evt, eIdx) => (
                            <div
                              key={eIdx}
                              className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                            >
                              <div className="flex items-center gap-2 truncate">
                                <span className="font-semibold text-slate-900 shrink-0">
                                  {evt.app}:
                                </span>
                                <span className="text-slate-700 truncate font-mono text-[11px]" title={evt.title}>
                                  {evt.title}
                                </span>
                              </div>
                              <div className="flex items-center gap-3 shrink-0 text-slate-500 font-mono text-[11px] tabular-nums">
                                <span>{Math.round(evt.dwell_s)}s dwell</span>
                                {evt.keys !== undefined && evt.keys > 0 && (
                                  <span>{evt.keys} keypresses</span>
                                )}
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-xs text-slate-500 italic p-2 bg-slate-50 rounded">
                            Continuous foreground dwell in {chunk.anchor_app}.
                          </div>
                        )}
                      </div>

                      {/* Unresolved threads / tasks */}
                      {chunk.unresolved_threads && chunk.unresolved_threads.length > 0 && (
                        <div className="mt-3 p-3 rounded-lg bg-blue-50/50 border border-blue-100 text-xs">
                          <div className="font-semibold text-blue-900 mb-1 flex items-center gap-1.5">
                            <Info className="w-3.5 h-3.5 text-blue-600" />
                            <span>Unresolved Context Items</span>
                          </div>
                          <ul className="list-disc list-inside text-blue-800 space-y-0.5 text-[11px]">
                            {chunk.unresolved_threads.map((thread, tIdx) => (
                              <li key={tIdx}>{thread}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
